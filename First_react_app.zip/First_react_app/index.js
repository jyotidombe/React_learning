/* rendering the h1 tag
ReactDOM.render(<h1>Hello, Everyone!</h1>,document.getElementById("root"))

rendering the p tag
ReactDOM.render(<p>Hello, Hi this jyoti </h1>,document.getElementById("root"))*/

/*rendering the ul tag*/

ReactDOM.render(
    <ul><li>Thing 1</li><li>Thing 2</li></ul>,
    document.getElementById("root")
)